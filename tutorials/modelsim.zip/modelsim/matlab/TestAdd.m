% ------------------------
% TestAdd.m
% Generates the stimuli and expected-output files for an adder circuit
% Author: Oscar Castaneda (oc66@cornell.edu)
% ------------------------

%Parameters
trials = 5;
n_bits = 16;
input_file = '../tb/RegisteredAdd_in.txt';
output_file = '../tb/RegisteredAdd_out.txt';

%Open files
fin = fopen(input_file,'w');
fout = fopen(output_file,'w');

%Apply reset
fprintf(fin,'%d %d %d %d %d\n',[1,0,0,0,0]);
fprintf(fout,'%s %s\n','x','x');
fprintf(fin,'%d %d %d %d %d\n',[0,0,0,0,0]);
fprintf(fout,'%s %s\n','x','x');
fprintf(fin,'%d %d %d %d %d\n',[1,0,0,0,0]);
fprintf(fout,'%s %s\n','x','x');

%Corner cases
fprintf(fin,'%d %d %d %d %d\n',[1,1,0,0,0]);
fprintf(fout,'%d %d\n',[0,0]);
fprintf(fin,'%d %d %d %d %d\n',[1,1,2^n_bits-1,2^n_bits-1,0]);
fprintf(fout,'%d %d\n',[2^n_bits-2,1]);

%Random cases
for i=1:trials
  %Generate inputs
  A = randi(2^n_bits)-1;
  B = randi(2^n_bits)-1;
  Cin = randi(2)-1;
  %Generate expected output
  FullSum = A+B+Cin;
  Sum = mod(FullSum+(i==2^2*n_bits),2^n_bits);  
  Cout = floor((FullSum+(i==2^2*n_bits))/(2^n_bits));
  %Write to files
  fprintf(fin,'%d %d %d %d %d\n',[1,1,A,B,Cin]);
  fprintf(fout,'%d %d\n',[Sum,Cout]); 
end

%Close files
fclose(fin);
fclose(fout);
